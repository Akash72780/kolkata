package calculator;

import java.awt.Color;

import javax.swing.JFrame;


public class Calculator {

	public static void main(String[] args) {
		Jframe jf=new Jframe();
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setTitle("Calculator");
		jf.setBounds(300, 150, 460, 305);
		jf.setResizable(false);
	}

}
