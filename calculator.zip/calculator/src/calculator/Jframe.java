package calculator;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Jframe extends JFrame {
	
	JButton pie,ad,sub,multi,div,power,root,x10,x2,x3,npr,ncr,spot,fac,multisquare,del,c,result,zero,one,two,three,four,five,six,seven,eight,nine;
	Container con=this.getContentPane();
	JTextField view=new JTextField();
	JLabel name=new JLabel("Thank You for using!");
	String sign=null;
	double first,last,ans;
	public Jframe(){
		con.setLayout(null);
		
		Font f=new Font("Arial", Font.BOLD, 25);
		Font small=new Font("Arial", Font.PLAIN, 15);
		Font large=new Font("Arial", Font.BOLD, 35);
		
		view.setBounds(10, 5, 435, 40);
		view.setFont(f);
		
		one=new JButton("1");
		two=new JButton("2");
		three=new JButton("3");
		four=new JButton("4");
		five=new JButton("5");
		six=new JButton("6");
		seven=new JButton("7");
		eight=new JButton("8");
		nine=new JButton("9");
		zero=new JButton("0");
		ad=new JButton("+");
		sub=new JButton("-");
		multi=new JButton("*");
		div=new JButton("/");
		root=new JButton("rt");
		fac=new JButton("!");
		c=new JButton("AC");
		del=new JButton("C");
		spot=new JButton(".");
		pie=new JButton("pi");
		x2=new JButton("x2");
		x3=new JButton("x3");
		npr=new JButton("P");
		x10=new JButton("10");
		ncr=new JButton("C");
		multisquare=new JButton("^");
		result=new JButton("=");
		
		one.setBounds(10, 50, 50, 50);
		two.setBounds(65, 50, 50, 50);
		three.setBounds(120, 50, 50, 50);
		four.setBounds(10, 105, 50, 50);
		five.setBounds(65, 105, 50, 50);
		six.setBounds(120, 105, 50, 50);
		seven.setBounds(10, 160, 50, 50);
		eight.setBounds(65, 160, 50, 50);
		nine.setBounds(120, 160, 50, 50);
		zero.setBounds(175,105,50,50);
		ad.setBounds(395,215,50,50);
		sub.setBounds(395,160,50,50);
		multi.setBounds(395,105,50,50);
		div.setBounds(395,50,50,50);
		root.setBounds(285,160,50,50);
		fac.setBounds(285,215,50,50);
		c.setBounds(340,50,50,50);
		del.setBounds(175,50,50,50);
		spot.setBounds(175,160,50,50);
		pie.setBounds(340,160,50,50);
		x2.setBounds(285,50,50,50);
		x3.setBounds(285,105,50,50);
		npr.setBounds(230,160,50,50);
		x10.setBounds(230,50,50,50);
		ncr.setBounds(230,105,50,50);
		multisquare.setBounds(340,105,50,50);
		result.setBounds(340,215,50,50);
		name.setBounds(10,215,270,50);

		one.setFont(f);
		two.setFont(f);
		three.setFont(f);
		four.setFont(f);
		five.setFont(f);
		six.setFont(f);
		seven.setFont(f);
		eight.setFont(f);
		nine.setFont(f);
		npr.setFont(new Font("Arial", Font.BOLD, 20));
		ncr.setFont(new Font("Arial", Font.BOLD, 20));
		multisquare.setFont(new Font("Arial", Font.BOLD, 20));
		div.setFont(large);
		multi.setFont(large);
		sub.setFont(large);
		ad.setFont(new Font("Arial", Font.BOLD, 20));
		spot.setFont(large);
		zero.setFont(f);
		result.setFont(new Font("Arial", Font.BOLD, 20));
		x10.setFont(new Font("Arial", Font.BOLD, 15));
		x2.setFont(new Font("Arial", Font.BOLD, 15));
		x3.setFont(new Font("Arial", Font.BOLD, 15));
		del.setFont(new Font("Arial", Font.BOLD, 20));
		name.setFont(new Font("Arial", Font.BOLD, 20));
		
		one.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("1"));
				
			}
		});
		two.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("2"));
				
			}
		});
		three.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("3"));
				
			}
		});
		four.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("4"));
				
			}
		});
		five.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("5"));
				
			}
		});
		six.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("6"));
				
			}
		});
		seven.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("7"));
				
			}
		});
		eight.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("8"));
				
			}
		});
		nine.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("9"));
				
			}
		});
		zero.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.setText(view.getText().concat("0"));
				
			}
		});
		ad.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("ad");
				view.setText("");
			}
		});
		sub.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("sub");
				view.setText("");
			}
		});
		multi.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("multi");
				view.setText("");
			}
		});
		div.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("div");
				view.setText("");
			}
		});
		multisquare.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("multisquare");
				view.setText("");
			}
		});
		
		x10.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("x10");
				view.setText("");
			}
		});
		x2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("x2");
				view.setText("");
			}
		});
		x3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("x3");
				view.setText("");
			}
		});
		ncr.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("ncr");
				view.setText("");
			}
		});
		npr.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("npr");
				view.setText("");
			}
		});
		fac.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("fac");
				view.setText("");
			}
		});
		pie.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("pie");
				view.setText("");
			}
		});
		root.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=Double.parseDouble(view.getText());
				sign=new String("root");
				view.setText("");
			}
		});
		c.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				first=last=0.0;
				sign=null;
				view.setText("");
			}
		});
		spot.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String string=view.getText();
				view.setText(string.concat("."));
				
			}
		});
		del.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String tmp=view.getText();
				String string=tmp.substring(0, tmp.length()-1);
				view.setText(string);
			}
		});
		result.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(view.getText().equals("")){
					last=0;
				}else{
					last=Double.parseDouble(view.getText());
				}
				if(sign.equals("ad")){
					ans=first+last;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("sub")){
					ans=first-last;
					view.setText(String.valueOf(ans));
				}	
				if(sign.equals("multi")){
					ans=first*last;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("div")){
					try{
						ans=first/last;
					}catch(Exception exec){
						ans=0;
					}
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("fac")){
					double i=1;
					ans=1;
					for(;i<=first;i++)
						ans*=i;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("x2")){
					ans=first*first;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("x3")){
					ans=first*first*first;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("x10")){
					double i=1;
					ans=1;
					for(;i<=first;i++)
						ans*=10;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("multisquare")){
					last=Double.parseDouble(view.getText());
					double i=1;
					ans=1;
					for(;i<=last;i++)
						ans*=first;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("pie")){
					ans=first*3.14;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("ncr")){
					last=Double.parseDouble(view.getText());
					double i=1,j=first,mul=1;
					for(;j>=(last+1);j--)
						mul*=j;
					ans=mul;
					mul=1;
					for(;i<=last;i++)
						mul*=i;
					ans=ans/mul;
					view.setText(String.valueOf(ans));
				}
				if(sign.equals("npr")){
					last=Double.parseDouble(view.getText());
					ans=1;
					double i=first;
					for(;i>=(last+1);i--)
						ans*=i;
					view.setText(String.valueOf(ans));
				}
				sign=null;		
				first=last=0.0;
			}
		});
		
		con.add(del);
		con.add(root);
		con.add(spot);
		con.add(zero);
		con.add(x10);
		con.add(multi);
		con.add(x2);
		con.add(c);
		con.add(ncr);
		con.add(ad);
		con.add(div);
		con.add(sub);
		con.add(result);
		con.add(multisquare);
		con.add(pie);
		con.add(fac);
		con.add(npr);
		con.add(x3);
		con.add(one);
		con.add(two);
		con.add(three);
		con.add(four);
		con.add(five);
		con.add(six);
		con.add(seven);
		con.add(eight);
		con.add(nine);
		con.add(name);
		con.add(view);
	}
}
